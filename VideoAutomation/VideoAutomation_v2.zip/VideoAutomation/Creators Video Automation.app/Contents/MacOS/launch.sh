#!/bin/bash
# Get the Resources directory
RESOURCES_DIR="$(dirname "$0")/../Resources"

# Create working directory in user's Documents
WORK_DIR="$HOME/Documents/VideoAutomation"
mkdir -p "$WORK_DIR"

# Copy scripts if they don't exist or are outdated
cp -f "$RESOURCES_DIR/video_app.py" "$WORK_DIR/"
cp -f "$RESOURCES_DIR/automate_videos.py" "$WORK_DIR/"
cp -f "$RESOURCES_DIR/process_timeline.py" "$WORK_DIR/"

# Change to working directory and run
cd "$WORK_DIR"
python3 video_app.py
