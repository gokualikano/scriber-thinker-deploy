#!/usr/bin/env python3
"""
YouTube Video Automation GUI
Creators! - PyQt5 Interface
"""

import sys
import os
import subprocess
import threading
from pathlib import Path
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QTabWidget, QTextEdit, QPushButton, 
                             QLabel, QProgressBar, QFileDialog, QMessageBox)
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtGui import QDragEnterEvent, QDropEvent, QFont

class DownloadThread(QThread):
    progress = pyqtSignal(str)
    finished = pyqtSignal(bool, str)
    
    def __init__(self, urls):
        super().__init__()
        self.urls = urls
    
    def run(self):
        try:
            # Create premiere_videos folder
            os.makedirs('premiere_videos', exist_ok=True)
            
            for i, url in enumerate(self.urls, 1):
                self.progress.emit(f"Downloading video {i}/{len(self.urls)}...")
                
                cmd = [
                    'yt-dlp',
                    '-f', 'bestvideo[vcodec^=avc1][ext=mp4]+bestaudio[ext=m4a]/best[vcodec^=avc1][ext=mp4]/best[ext=mp4]/best',
                    '--merge-output-format', 'mp4',
                    '-o', 'premiere_videos/%(title)s.%(ext)s',
                    '--restrict-filenames',
                    url
                ]
                
                result = subprocess.run(cmd, capture_output=True, text=True)
                
                if result.returncode != 0:
                    self.progress.emit(f"Failed to download video {i}, skipping...")
            
            self.finished.emit(True, f"Successfully downloaded {len(self.urls)} videos!")
            
        except Exception as e:
            self.finished.emit(False, f"Error: {str(e)}")

class ProcessThread(QThread):
    progress = pyqtSignal(str)
    finished = pyqtSignal(bool, str)
    
    def __init__(self, xml_path):
        super().__init__()
        self.xml_path = xml_path
    
    def run(self):
        try:
            self.progress.emit("Processing XML...")
            
            # Run the process_timeline.py script
            result = subprocess.run(
                ['python3', 'process_timeline.py'],
                capture_output=True,
                text=True,
                cwd=os.getcwd()
            )
            
            if result.returncode == 0 and os.path.exists('timeline_processed.xml'):
                self.finished.emit(True, "Successfully processed! timeline_processed.xml created.")
            else:
                self.finished.emit(False, f"Processing failed: {result.stderr}")
                
        except Exception as e:
            self.finished.emit(False, f"Error: {str(e)}")

class DropArea(QWidget):
    file_dropped = pyqtSignal(str)
    
    def __init__(self):
        super().__init__()
        self.setAcceptDrops(True)
        self.setMinimumHeight(150)
        
        layout = QVBoxLayout()
        
        label = QLabel("📁 DRAG & DROP timeline.xml HERE\n\nOR CLICK BROWSE BUTTON BELOW")
        label.setAlignment(Qt.AlignCenter)
        label.setStyleSheet("""
            QLabel {
                border: 3px dashed #FFFF00;
                border-radius: 12px;
                padding: 45px;
                background-color: #0a0a0a;
                font-size: 15px;
                font-weight: bold;
                color: #FFFF00;
            }
        """)
        
        layout.addWidget(label)
        self.setLayout(layout)
        self.label = label
    
    def dragEnterEvent(self, event: QDragEnterEvent):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
            self.label.setStyleSheet("""
                QLabel {
                    border: 3px dashed #00FF00;
                    border-radius: 12px;
                    padding: 45px;
                    background-color: #001a00;
                    font-size: 15px;
                    font-weight: bold;
                    color: #00FF00;
                }
            """)
    
    def dragLeaveEvent(self, event):
        self.label.setStyleSheet("""
            QLabel {
                border: 3px dashed #FFFF00;
                border-radius: 12px;
                padding: 45px;
                background-color: #0a0a0a;
                font-size: 15px;
                font-weight: bold;
                color: #FFFF00;
            }
        """)
    
    def dropEvent(self, event: QDropEvent):
        files = [u.toLocalFile() for u in event.mimeData().urls()]
        if files and files[0].endswith('.xml'):
            self.file_dropped.emit(files[0])
            self.label.setText(f"✅ Selected: {os.path.basename(files[0])}")
        self.dragLeaveEvent(event)

class VideoAutomationApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("YouTube Video Automation - Creators!")
        self.setGeometry(100, 100, 800, 600)
        
        # Main widget
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        
        # Main layout
        layout = QVBoxLayout()
        main_widget.setLayout(layout)
        
        # Title
        title = QLabel("⚡ CREATORS! VIDEO AUTOMATION ⚡")
        title.setFont(QFont("Arial", 22, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("padding: 25px; color: #FFFF00; background-color: #000000;")
        layout.addWidget(title)
        
        # Tabs
        tabs = QTabWidget()
        tabs.addTab(self.create_download_tab(), "📥 Download Videos")
        tabs.addTab(self.create_process_tab(), "⚙️ Process Timeline")
        layout.addWidget(tabs)
        
        # Apply styling - SICK BLACK & NEON YELLOW THEME
        self.setStyleSheet("""
            QMainWindow {
                background-color: #000000;
            }
            QWidget {
                background-color: #000000;
                color: #FFFF00;
            }
            QTabWidget::pane {
                border: 2px solid #FFFF00;
                border-radius: 8px;
                background-color: #000000;
            }
            QTabBar::tab {
                background-color: #1a1a1a;
                color: #FFFF00;
                padding: 12px 25px;
                margin-right: 3px;
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
                font-weight: bold;
                font-size: 13px;
            }
            QTabBar::tab:selected {
                background-color: #000000;
                border: 2px solid #FFFF00;
                border-bottom: none;
            }
            QTabBar::tab:hover {
                background-color: #2a2a2a;
            }
            QPushButton {
                background-color: #FFFF00;
                color: #000000;
                border: 2px solid #FFFF00;
                padding: 15px 35px;
                border-radius: 8px;
                font-size: 15px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #000000;
                color: #FFFF00;
                border: 2px solid #FFFF00;
            }
            QPushButton:pressed {
                background-color: #CCCC00;
                color: #000000;
            }
            QPushButton:disabled {
                background-color: #333333;
                color: #666666;
                border: 2px solid #333333;
            }
            QTextEdit {
                border: 2px solid #FFFF00;
                border-radius: 8px;
                padding: 12px;
                font-family: 'Courier New';
                font-size: 13px;
                background-color: #0a0a0a;
                color: #FFFF00;
                font-weight: bold;
            }
            QProgressBar {
                border: 2px solid #FFFF00;
                border-radius: 8px;
                text-align: center;
                height: 30px;
                background-color: #0a0a0a;
                color: #FFFF00;
                font-weight: bold;
            }
            QProgressBar::chunk {
                background-color: #FFFF00;
                border-radius: 6px;
            }
            QLabel {
                color: #FFFF00;
                font-weight: bold;
            }
        """)
    
    def create_download_tab(self):
        tab = QWidget()
        layout = QVBoxLayout()
        
        # Instructions
        instructions = QLabel("PASTE YOUTUBE URLs BELOW (ONE PER LINE):")
        instructions.setStyleSheet("font-size: 14px; padding: 12px; color: #FFFF00; font-weight: bold;")
        layout.addWidget(instructions)
        
        # URL text area
        self.url_text = QTextEdit()
        self.url_text.setPlaceholderText("https://www.youtube.com/watch?v=example1\nhttps://www.youtube.com/watch?v=example2\nhttps://www.youtube.com/watch?v=example3")
        layout.addWidget(self.url_text)
        
        # Download button
        self.download_btn = QPushButton("📥 Download Videos (H.264)")
        self.download_btn.clicked.connect(self.start_download)
        layout.addWidget(self.download_btn)
        
        # Progress bar
        self.download_progress = QProgressBar()
        self.download_progress.setVisible(False)
        layout.addWidget(self.download_progress)
        
        # Status label
        self.download_status = QLabel("")
        self.download_status.setAlignment(Qt.AlignCenter)
        self.download_status.setStyleSheet("padding: 12px; font-size: 13px; font-weight: bold;")
        layout.addWidget(self.download_status)
        
        tab.setLayout(layout)
        return tab
    
    def create_process_tab(self):
        tab = QWidget()
        layout = QVBoxLayout()
        
        # Instructions
        instructions = QLabel("1. EXPORT PREMIERE TIMELINE AS 'FINAL CUT PRO XML'\n2. DROP IT BELOW OR BROWSE FOR IT\n3. CLICK PROCESS TO CUT, SHUFFLE & ADD COLOR LABELS")
        instructions.setStyleSheet("font-size: 14px; padding: 12px; color: #FFFF00; font-weight: bold;")
        layout.addWidget(instructions)
        
        # Drop area
        self.drop_area = DropArea()
        self.drop_area.file_dropped.connect(self.file_selected)
        layout.addWidget(self.drop_area)
        
        # Browse button
        browse_btn = QPushButton("📂 Browse for timeline.xml")
        browse_btn.clicked.connect(self.browse_file)
        layout.addWidget(browse_btn)
        
        # Process button
        self.process_btn = QPushButton("⚙️ Cut, Shuffle & Add Colors")
        self.process_btn.clicked.connect(self.start_processing)
        self.process_btn.setEnabled(False)
        layout.addWidget(self.process_btn)
        
        # Progress bar
        self.process_progress = QProgressBar()
        self.process_progress.setVisible(False)
        layout.addWidget(self.process_progress)
        
        # Status label
        self.process_status = QLabel("")
        self.process_status.setAlignment(Qt.AlignCenter)
        self.process_status.setStyleSheet("padding: 12px; font-size: 13px; font-weight: bold;")
        layout.addWidget(self.process_status)
        
        # Open folder button
        self.open_folder_btn = QPushButton("📁 Open Output Folder")
        self.open_folder_btn.clicked.connect(self.open_output_folder)
        self.open_folder_btn.setVisible(False)
        layout.addWidget(self.open_folder_btn)
        
        tab.setLayout(layout)
        return tab
    
    def start_download(self):
        urls_text = self.url_text.toPlainText().strip()
        if not urls_text:
            QMessageBox.warning(self, "No URLs", "Please paste YouTube URLs first!")
            return
        
        urls = [url.strip() for url in urls_text.split('\n') if url.strip()]
        
        if not urls:
            QMessageBox.warning(self, "No URLs", "Please paste valid YouTube URLs!")
            return
        
        # Disable button and show progress
        self.download_btn.setEnabled(False)
        self.download_progress.setVisible(True)
        self.download_progress.setRange(0, 0)  # Indeterminate
        self.download_status.setText("Downloading videos...")
        
        # Start download thread
        self.download_thread = DownloadThread(urls)
        self.download_thread.progress.connect(self.update_download_progress)
        self.download_thread.finished.connect(self.download_finished)
        self.download_thread.start()
    
    def update_download_progress(self, message):
        self.download_status.setText(message)
    
    def download_finished(self, success, message):
        self.download_btn.setEnabled(True)
        self.download_progress.setVisible(False)
        
        if success:
            self.download_status.setText(f"✅ {message}")
            self.download_status.setStyleSheet("padding: 12px; font-size: 13px; color: #00FF00; font-weight: bold;")
            QMessageBox.information(self, "Success", f"{message}\n\nVideos are in 'premiere_videos' folder.\n\nNext: Import to Premiere, scale clips, export XML.")
        else:
            self.download_status.setText(f"❌ {message}")
            self.download_status.setStyleSheet("padding: 12px; font-size: 13px; color: #FF0000; font-weight: bold;")
            QMessageBox.critical(self, "Error", message)
    
    def browse_file(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select timeline.xml",
            "",
            "XML Files (*.xml)"
        )
        if file_path:
            self.file_selected(file_path)
    
    def file_selected(self, file_path):
        # Copy file to timeline.xml if it has a different name
        if os.path.basename(file_path) != 'timeline.xml':
            import shutil
            shutil.copy(file_path, 'timeline.xml')
            self.process_status.setText(f"✅ Copied: {os.path.basename(file_path)} → timeline.xml")
        else:
            self.process_status.setText(f"✅ Selected: timeline.xml")
        
        self.process_status.setStyleSheet("padding: 12px; font-size: 13px; color: #00FF00; font-weight: bold;")
        self.process_btn.setEnabled(True)
        self.selected_file = file_path
    
    def start_processing(self):
        if not os.path.exists('timeline.xml'):
            QMessageBox.warning(self, "No File", "Please select timeline.xml first!")
            return
        
        # Disable button and show progress
        self.process_btn.setEnabled(False)
        self.process_progress.setVisible(True)
        self.process_progress.setRange(0, 0)  # Indeterminate
        self.process_status.setText("Processing: Cutting to 6 seconds & shuffling...")
        self.open_folder_btn.setVisible(False)
        
        # Start processing thread
        self.process_thread = ProcessThread('timeline.xml')
        self.process_thread.progress.connect(self.update_process_progress)
        self.process_thread.finished.connect(self.process_finished)
        self.process_thread.start()
    
    def update_process_progress(self, message):
        self.process_status.setText(message)
    
    def process_finished(self, success, message):
        self.process_btn.setEnabled(True)
        self.process_progress.setVisible(False)
        
        if success:
            self.process_status.setText(f"✅ {message}")
            self.process_status.setStyleSheet("padding: 12px; font-size: 13px; color: #00FF00; font-weight: bold;")
            self.open_folder_btn.setVisible(True)
            QMessageBox.information(self, "Success", f"{message}\n\nNext: Import 'timeline_processed.xml' to Premiere Pro!")
        else:
            self.process_status.setText(f"❌ {message}")
            self.process_status.setStyleSheet("padding: 12px; font-size: 13px; color: #FF0000; font-weight: bold;")
            QMessageBox.critical(self, "Error", message)
    
    def open_output_folder(self):
        folder = os.getcwd()
        subprocess.run(['open', folder])

def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Video Automation - Creators!")
    
    window = VideoAutomationApp()
    window.show()
    
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()