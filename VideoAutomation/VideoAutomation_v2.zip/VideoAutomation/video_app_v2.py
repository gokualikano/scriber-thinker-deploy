#!/usr/bin/env python3
"""
YouTube Video Automation GUI - V2 ENHANCED
Creators! - PyQt5 Interface with:
- Per-video download progress
- Green tick / Red cross status
- Auto-retry failed downloads
- Better error handling
"""

import sys
import os
import subprocess
import re
import shutil
from pathlib import Path
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QTabWidget, QTextEdit, QPushButton, 
                             QLabel, QProgressBar, QFileDialog, QMessageBox,
                             QListWidget, QListWidgetItem, QSplitter)
from PyQt5.QtCore import Qt, QThread, pyqtSignal, QTimer
from PyQt5.QtGui import QFont, QPixmap, QColor, QIcon

class VideoDownloadWorker(QThread):
    """Worker thread for downloading a single video with progress tracking"""
    progress = pyqtSignal(int, str, int)  # index, status_message, percentage
    finished = pyqtSignal(int, bool, str)  # index, success, error_message
    
    def __init__(self, index, url, output_dir):
        super().__init__()
        self.index = index
        self.url = url
        self.output_dir = output_dir
    
    def run(self):
        try:
            # Validate URL
            if not self.url.startswith(('http://', 'https://')):
                self.finished.emit(self.index, False, "Invalid URL format")
                return
            
            # Build yt-dlp command
            cmd = [
                'yt-dlp',
                '-f', 'bestvideo[vcodec^=avc1][ext=mp4]+bestaudio[ext=m4a]/best[vcodec^=avc1][ext=mp4]/best[ext=mp4]/best',
                '--merge-output-format', 'mp4',
                '-o', f'{self.output_dir}/%(title)s.%(ext)s',
                '--restrict-filenames',
                '--no-part',
                '--retries', '3',
                '--newline',  # Progress on new lines for parsing
                '--progress-template', '%(progress._percent_str)s',
                self.url
            ]
            
            # Run with live output parsing
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1
            )
            
            last_percent = 0
            for line in process.stdout:
                line = line.strip()
                
                # Parse percentage from yt-dlp output
                percent_match = re.search(r'(\d+\.?\d*)%', line)
                if percent_match:
                    try:
                        percent = int(float(percent_match.group(1)))
                        if percent != last_percent:
                            last_percent = percent
                            self.progress.emit(self.index, f"Downloading... {percent}%", percent)
                    except:
                        pass
                
                # Check for download status messages
                if '[download]' in line.lower():
                    self.progress.emit(self.index, "Downloading...", last_percent)
                elif '[merger]' in line.lower() or 'merging' in line.lower():
                    self.progress.emit(self.index, "Merging audio/video...", 95)
            
            process.wait()
            
            if process.returncode == 0:
                self.progress.emit(self.index, "Complete!", 100)
                self.finished.emit(self.index, True, "")
            else:
                self.finished.emit(self.index, False, "Download failed - video may be unavailable or restricted")
                
        except FileNotFoundError:
            self.finished.emit(self.index, False, "yt-dlp not found. Install with: brew install yt-dlp")
        except Exception as e:
            self.finished.emit(self.index, False, str(e))


class DownloadManager(QThread):
    """Manages sequential downloads with retry logic"""
    video_started = pyqtSignal(int)  # index
    video_progress = pyqtSignal(int, str, int)  # index, message, percent
    video_finished = pyqtSignal(int, bool, str)  # index, success, error
    all_finished = pyqtSignal(int, int, list)  # success_count, total, failed_indices
    retry_starting = pyqtSignal()
    
    def __init__(self, urls, output_dir):
        super().__init__()
        self.urls = urls
        self.output_dir = output_dir
        self.results = {}  # index -> (success, error)
    
    def download_video(self, index, url):
        """Download a single video and return result"""
        try:
            if not url.startswith(('http://', 'https://')):
                return False, "Invalid URL format"
            
            cmd = [
                'yt-dlp',
                '-f', 'bestvideo[vcodec^=avc1][ext=mp4]+bestaudio[ext=m4a]/best[vcodec^=avc1][ext=mp4]/best[ext=mp4]/best',
                '--merge-output-format', 'mp4',
                '-o', f'{self.output_dir}/%(title)s.%(ext)s',
                '--restrict-filenames',
                '--no-part',
                '--retries', '3',
                '--newline',
                self.url if hasattr(self, 'url') else url
            ]
            
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1
            )
            
            last_percent = 0
            for line in process.stdout:
                line = line.strip()
                percent_match = re.search(r'(\d+\.?\d*)%', line)
                if percent_match:
                    try:
                        percent = int(float(percent_match.group(1)))
                        if percent != last_percent:
                            last_percent = percent
                            self.video_progress.emit(index, f"Downloading... {percent}%", percent)
                    except:
                        pass
                
                if 'merging' in line.lower() or '[merger]' in line.lower():
                    self.video_progress.emit(index, "Merging...", 95)
            
            process.wait()
            
            if process.returncode == 0:
                return True, ""
            else:
                return False, "Download failed"
                
        except FileNotFoundError:
            return False, "yt-dlp not found"
        except Exception as e:
            return False, str(e)
    
    def run(self):
        os.makedirs(self.output_dir, exist_ok=True)
        
        failed_indices = []
        success_count = 0
        
        # First pass: download all videos
        for i, url in enumerate(self.urls):
            self.video_started.emit(i)
            self.video_progress.emit(i, "Starting download...", 0)
            
            success, error = self.download_single(i, url)
            
            self.results[i] = (success, error)
            
            if success:
                success_count += 1
                self.video_progress.emit(i, "Complete!", 100)
                self.video_finished.emit(i, True, "")
            else:
                failed_indices.append(i)
                self.video_finished.emit(i, False, error)
        
        # Retry pass: retry failed downloads once
        if failed_indices:
            self.retry_starting.emit()
            
            retry_indices = failed_indices.copy()
            failed_indices = []
            
            for i in retry_indices:
                url = self.urls[i]
                self.video_started.emit(i)
                self.video_progress.emit(i, "Retrying...", 0)
                
                success, error = self.download_single(i, url)
                
                if success:
                    success_count += 1
                    self.video_progress.emit(i, "Complete! (retry)", 100)
                    self.video_finished.emit(i, True, "")
                else:
                    failed_indices.append(i)
                    self.video_finished.emit(i, False, f"Retry failed: {error}")
        
        self.all_finished.emit(success_count, len(self.urls), failed_indices)
    
    def download_single(self, index, url):
        """Download a single video"""
        try:
            if not url.startswith(('http://', 'https://')):
                return False, "Invalid URL"
            
            cmd = [
                'yt-dlp',
                '-f', 'bestvideo[vcodec^=avc1][ext=mp4]+bestaudio[ext=m4a]/best[vcodec^=avc1][ext=mp4]/best[ext=mp4]/best',
                '--merge-output-format', 'mp4',
                '-o', f'{self.output_dir}/%(title)s.%(ext)s',
                '--restrict-filenames',
                '--no-part',
                '--retries', '3',
                '--newline',
                url
            ]
            
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1
            )
            
            last_percent = 0
            for line in process.stdout:
                line = line.strip()
                percent_match = re.search(r'(\d+\.?\d*)%', line)
                if percent_match:
                    try:
                        percent = int(float(percent_match.group(1)))
                        if percent > last_percent:
                            last_percent = percent
                            self.video_progress.emit(index, f"Downloading... {percent}%", percent)
                    except:
                        pass
                
                if 'merging' in line.lower() or '[merger]' in line.lower():
                    self.video_progress.emit(index, "Merging audio/video...", 95)
            
            process.wait()
            return process.returncode == 0, "" if process.returncode == 0 else "Download failed"
            
        except FileNotFoundError:
            return False, "yt-dlp not found"
        except Exception as e:
            return False, str(e)


class ProcessThread(QThread):
    """Thread for XML processing"""
    progress = pyqtSignal(str, int)
    finished = pyqtSignal(bool, str)
    
    def __init__(self, xml_path):
        super().__init__()
        self.xml_path = xml_path
    
    def run(self):
        try:
            script_dir = os.path.dirname(os.path.abspath(__file__))
            process_script = os.path.join(script_dir, 'process_timeline.py')
            
            if not os.path.exists(process_script):
                if os.path.exists('process_timeline.py'):
                    process_script = 'process_timeline.py'
                else:
                    self.finished.emit(False, "ERROR: process_timeline.py not found")
                    return
            
            if not os.path.exists('timeline.xml'):
                self.finished.emit(False, "ERROR: timeline.xml not found")
                return
            
            self.progress.emit("Reading XML file...", 20)
            
            try:
                import xml.etree.ElementTree as ET
                tree = ET.parse('timeline.xml')
                root = tree.getroot()
                if root.find('.//sequence') is None:
                    self.finished.emit(False, "ERROR: Invalid XML - No sequence found")
                    return
            except Exception as e:
                self.finished.emit(False, f"ERROR: Cannot parse XML: {str(e)}")
                return
            
            self.progress.emit("Processing clips...", 50)
            
            result = subprocess.run(
                ['python3', process_script],
                capture_output=True,
                text=True,
                cwd=os.getcwd(),
                input='\n'
            )
            
            self.progress.emit("Finalizing...", 90)
            
            if os.path.exists('timeline_processed.xml') and os.path.getsize('timeline_processed.xml') > 0:
                self.finished.emit(True, "✅ Successfully processed!\n\ntimeline_processed.xml created")
            else:
                self.finished.emit(False, f"Processing failed:\n{result.stderr[:300] if result.stderr else result.stdout[:300]}")
                
        except Exception as e:
            self.finished.emit(False, f"ERROR: {str(e)}")


class VideoListItem(QWidget):
    """Custom widget for video list items with status"""
    def __init__(self, index, url):
        super().__init__()
        self.index = index
        self.url = url
        
        layout = QHBoxLayout()
        layout.setContentsMargins(5, 5, 5, 5)
        
        # Status icon
        self.status_label = QLabel("⏳")
        self.status_label.setFixedWidth(30)
        self.status_label.setFont(QFont("Arial", 16))
        layout.addWidget(self.status_label)
        
        # URL and progress info
        info_layout = QVBoxLayout()
        
        # URL (truncated)
        display_url = url[:60] + "..." if len(url) > 60 else url
        self.url_label = QLabel(f"{index + 1}. {display_url}")
        self.url_label.setStyleSheet("color: #FFFF00; font-size: 12px;")
        info_layout.addWidget(self.url_label)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(15)
        self.progress_bar.setTextVisible(True)
        self.progress_bar.setFormat("%p%")
        self.progress_bar.setValue(0)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                border: 1px solid #FFFF00;
                border-radius: 3px;
                background-color: #1a1a1a;
                text-align: center;
                color: #000;
                font-size: 10px;
            }
            QProgressBar::chunk {
                background-color: #FFFF00;
            }
        """)
        info_layout.addWidget(self.progress_bar)
        
        # Status text
        self.status_text = QLabel("Waiting...")
        self.status_text.setStyleSheet("color: #888; font-size: 11px;")
        info_layout.addWidget(self.status_text)
        
        layout.addLayout(info_layout)
        self.setLayout(layout)
    
    def set_waiting(self):
        self.status_label.setText("⏳")
        self.status_text.setText("Waiting...")
        self.progress_bar.setValue(0)
    
    def set_downloading(self, message="Downloading...", percent=0):
        self.status_label.setText("📥")
        self.status_text.setText(message)
        self.status_text.setStyleSheet("color: #FFFF00; font-size: 11px;")
        self.progress_bar.setValue(percent)
    
    def set_success(self):
        self.status_label.setText("✅")
        self.status_text.setText("Downloaded successfully!")
        self.status_text.setStyleSheet("color: #00FF00; font-size: 11px;")
        self.progress_bar.setValue(100)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                border: 1px solid #00FF00;
                border-radius: 3px;
                background-color: #1a1a1a;
                text-align: center;
                color: #000;
                font-size: 10px;
            }
            QProgressBar::chunk {
                background-color: #00FF00;
            }
        """)
    
    def set_failed(self, error="Download failed"):
        self.status_label.setText("❌")
        self.status_text.setText(error[:50])
        self.status_text.setStyleSheet("color: #FF4444; font-size: 11px;")
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                border: 1px solid #FF4444;
                border-radius: 3px;
                background-color: #1a1a1a;
                text-align: center;
                color: #FFF;
                font-size: 10px;
            }
            QProgressBar::chunk {
                background-color: #FF4444;
            }
        """)
    
    def set_retrying(self):
        self.status_label.setText("🔄")
        self.status_text.setText("Retrying...")
        self.status_text.setStyleSheet("color: #FFA500; font-size: 11px;")
        self.progress_bar.setValue(0)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                border: 1px solid #FFA500;
                border-radius: 3px;
                background-color: #1a1a1a;
                text-align: center;
                color: #000;
                font-size: 10px;
            }
            QProgressBar::chunk {
                background-color: #FFA500;
            }
        """)


class DropArea(QWidget):
    """Drag and drop area for XML files"""
    file_dropped = pyqtSignal(str)
    
    def __init__(self):
        super().__init__()
        self.setAcceptDrops(True)
        self.setMinimumHeight(120)
        
        layout = QVBoxLayout()
        
        self.label = QLabel("📁 DRAG & DROP timeline.xml HERE\n\nOR CLICK BROWSE BELOW")
        self.label.setAlignment(Qt.AlignCenter)
        self.label.setStyleSheet("""
            QLabel {
                border: 3px dashed #FFFF00;
                border-radius: 12px;
                padding: 30px;
                background-color: #0a0a0a;
                font-size: 14px;
                font-weight: bold;
                color: #FFFF00;
            }
        """)
        
        layout.addWidget(self.label)
        self.setLayout(layout)
    
    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
            self.label.setStyleSheet("""
                QLabel {
                    border: 3px dashed #00FF00;
                    border-radius: 12px;
                    padding: 30px;
                    background-color: #001a00;
                    font-size: 14px;
                    font-weight: bold;
                    color: #00FF00;
                }
            """)
    
    def dragLeaveEvent(self, event):
        self.label.setStyleSheet("""
            QLabel {
                border: 3px dashed #FFFF00;
                border-radius: 12px;
                padding: 30px;
                background-color: #0a0a0a;
                font-size: 14px;
                font-weight: bold;
                color: #FFFF00;
            }
        """)
    
    def dropEvent(self, event):
        files = [u.toLocalFile() for u in event.mimeData().urls()]
        if files and files[0].endswith('.xml'):
            self.file_dropped.emit(files[0])
            self.label.setText(f"✅ SELECTED:\n{os.path.basename(files[0])}")
        else:
            self.label.setText("❌ ERROR: Must be an XML file!")
        self.dragLeaveEvent(event)


class VideoAutomationApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Creators! Video Automation v2")
        self.setGeometry(100, 100, 1000, 800)
        
        self.video_items = []
        self.download_manager = None
        
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        layout = QVBoxLayout()
        main_widget.setLayout(layout)
        
        # Logo
        logo_layout = QHBoxLayout()
        logo_layout.addStretch()
        
        script_dir = os.path.dirname(os.path.abspath(__file__))
        logo_path = os.path.join(script_dir, 'logo.png')
        if not os.path.exists(logo_path):
            logo_path = 'logo.png'
        
        if os.path.exists(logo_path):
            logo_label = QLabel()
            pixmap = QPixmap(logo_path)
            scaled = pixmap.scaledToWidth(180, Qt.SmoothTransformation)
            logo_label.setPixmap(scaled)
            logo_layout.addWidget(logo_label)
        
        logo_layout.addStretch()
        layout.addLayout(logo_layout)
        
        # Title
        title = QLabel("⚡ VIDEO AUTOMATION SYSTEM v2 ⚡")
        title.setFont(QFont("Arial", 22, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("padding: 15px; color: #FFFF00; background-color: #000;")
        layout.addWidget(title)
        
        # Tabs
        tabs = QTabWidget()
        tabs.addTab(self.create_download_tab(), "📥 DOWNLOAD VIDEOS")
        tabs.addTab(self.create_process_tab(), "⚙️ PROCESS TIMELINE")
        layout.addWidget(tabs)
        
        self.apply_styles()
    
    def create_download_tab(self):
        tab = QWidget()
        layout = QVBoxLayout()
        
        # Instructions
        instructions = QLabel("PASTE YOUTUBE URLs BELOW (ONE PER LINE):")
        instructions.setStyleSheet("font-size: 14px; padding: 10px; color: #FFFF00;")
        layout.addWidget(instructions)
        
        # Splitter for URL input and video list
        splitter = QSplitter(Qt.Vertical)
        
        # URL text area
        self.url_text = QTextEdit()
        self.url_text.setPlaceholderText("https://www.youtube.com/watch?v=example1\nhttps://www.youtube.com/watch?v=example2")
        self.url_text.setMaximumHeight(150)
        splitter.addWidget(self.url_text)
        
        # Video list widget (shows status of each video)
        video_list_container = QWidget()
        video_list_layout = QVBoxLayout()
        video_list_layout.setContentsMargins(0, 0, 0, 0)
        
        list_label = QLabel("📋 DOWNLOAD STATUS:")
        list_label.setStyleSheet("font-size: 13px; padding: 5px; color: #FFFF00;")
        video_list_layout.addWidget(list_label)
        
        self.video_list_widget = QWidget()
        self.video_list_layout = QVBoxLayout()
        self.video_list_layout.setAlignment(Qt.AlignTop)
        self.video_list_widget.setLayout(self.video_list_layout)
        
        from PyQt5.QtWidgets import QScrollArea
        scroll = QScrollArea()
        scroll.setWidget(self.video_list_widget)
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea { border: 2px solid #FFFF00; border-radius: 8px; background: #0a0a0a; }")
        video_list_layout.addWidget(scroll)
        
        video_list_container.setLayout(video_list_layout)
        splitter.addWidget(video_list_container)
        
        layout.addWidget(splitter)
        
        # Buttons
        btn_layout = QHBoxLayout()
        
        self.download_btn = QPushButton("📥 START DOWNLOAD")
        self.download_btn.clicked.connect(self.start_download)
        btn_layout.addWidget(self.download_btn)
        
        self.open_folder_btn = QPushButton("📁 OPEN FOLDER")
        self.open_folder_btn.clicked.connect(self.open_download_folder)
        self.open_folder_btn.setEnabled(False)
        btn_layout.addWidget(self.open_folder_btn)
        
        layout.addLayout(btn_layout)
        
        # Overall progress
        self.overall_progress = QProgressBar()
        self.overall_progress.setVisible(False)
        self.overall_progress.setFormat("Overall: %p%")
        layout.addWidget(self.overall_progress)
        
        # Status
        self.download_status = QLabel("")
        self.download_status.setAlignment(Qt.AlignCenter)
        self.download_status.setStyleSheet("padding: 10px; font-size: 14px;")
        self.download_status.setWordWrap(True)
        layout.addWidget(self.download_status)
        
        tab.setLayout(layout)
        return tab
    
    def create_process_tab(self):
        tab = QWidget()
        layout = QVBoxLayout()
        
        instructions = QLabel("1. EXPORT PREMIERE TIMELINE AS 'FINAL CUT PRO XML'\n2. DROP IT BELOW OR BROWSE\n3. CLICK PROCESS")
        instructions.setStyleSheet("font-size: 14px; padding: 10px; color: #FFFF00;")
        layout.addWidget(instructions)
        
        self.drop_area = DropArea()
        self.drop_area.file_dropped.connect(self.file_selected)
        layout.addWidget(self.drop_area)
        
        browse_btn = QPushButton("📂 BROWSE FOR XML")
        browse_btn.clicked.connect(self.browse_file)
        layout.addWidget(browse_btn)
        
        self.process_btn = QPushButton("⚙️ PROCESS TIMELINE")
        self.process_btn.clicked.connect(self.start_processing)
        self.process_btn.setEnabled(False)
        layout.addWidget(self.process_btn)
        
        self.process_progress = QProgressBar()
        self.process_progress.setVisible(False)
        layout.addWidget(self.process_progress)
        
        self.process_status = QLabel("")
        self.process_status.setAlignment(Qt.AlignCenter)
        self.process_status.setStyleSheet("padding: 10px; font-size: 14px;")
        self.process_status.setWordWrap(True)
        layout.addWidget(self.process_status)
        
        self.open_output_btn = QPushButton("📁 OPEN OUTPUT FOLDER")
        self.open_output_btn.clicked.connect(self.open_output_folder)
        self.open_output_btn.setVisible(False)
        layout.addWidget(self.open_output_btn)
        
        tab.setLayout(layout)
        return tab
    
    def start_download(self):
        urls_text = self.url_text.toPlainText().strip()
        if not urls_text:
            QMessageBox.warning(self, "No URLs", "Please paste YouTube URLs first!")
            return
        
        urls = [u.strip() for u in urls_text.split('\n') if u.strip() and not u.startswith('#')]
        
        if not urls:
            QMessageBox.warning(self, "No Valid URLs", "No valid URLs found!")
            return
        
        # Clear previous items
        for item in self.video_items:
            self.video_list_layout.removeWidget(item)
            item.deleteLater()
        self.video_items = []
        
        # Create video list items
        for i, url in enumerate(urls):
            item = VideoListItem(i, url)
            self.video_items.append(item)
            self.video_list_layout.addWidget(item)
        
        # Setup UI
        self.download_btn.setEnabled(False)
        self.overall_progress.setVisible(True)
        self.overall_progress.setValue(0)
        self.overall_progress.setMaximum(len(urls))
        self.download_status.setText("Starting downloads...")
        self.download_status.setStyleSheet("padding: 10px; font-size: 14px; color: #FFFF00;")
        
        # Get output directory
        script_dir = os.path.dirname(os.path.abspath(__file__))
        output_dir = os.path.join(script_dir, 'premiere_videos')
        if not os.path.exists(output_dir):
            output_dir = 'premiere_videos'
        
        # Start download manager
        self.download_manager = DownloadManager(urls, output_dir)
        self.download_manager.video_started.connect(self.on_video_started)
        self.download_manager.video_progress.connect(self.on_video_progress)
        self.download_manager.video_finished.connect(self.on_video_finished)
        self.download_manager.all_finished.connect(self.on_all_finished)
        self.download_manager.retry_starting.connect(self.on_retry_starting)
        self.download_manager.start()
    
    def on_video_started(self, index):
        if index < len(self.video_items):
            self.video_items[index].set_downloading("Starting...", 0)
    
    def on_video_progress(self, index, message, percent):
        if index < len(self.video_items):
            self.video_items[index].set_downloading(message, percent)
    
    def on_video_finished(self, index, success, error):
        if index < len(self.video_items):
            if success:
                self.video_items[index].set_success()
            else:
                self.video_items[index].set_failed(error)
        
        # Update overall progress
        completed = sum(1 for item in self.video_items 
                       if item.status_label.text() in ["✅", "❌"])
        self.overall_progress.setValue(completed)
    
    def on_retry_starting(self):
        self.download_status.setText("🔄 Retrying failed downloads...")
        self.download_status.setStyleSheet("padding: 10px; font-size: 14px; color: #FFA500;")
        
        # Mark failed items as retrying
        for item in self.video_items:
            if item.status_label.text() == "❌":
                item.set_retrying()
    
    def on_all_finished(self, success_count, total, failed_indices):
        self.download_btn.setEnabled(True)
        self.overall_progress.setValue(total)
        self.open_folder_btn.setEnabled(True)
        
        if failed_indices:
            self.download_status.setText(f"⚠️ Completed: {success_count}/{total} videos downloaded")
            self.download_status.setStyleSheet("padding: 10px; font-size: 14px; color: #FFA500;")
            
            failed_list = ", ".join(str(i+1) for i in failed_indices[:5])
            if len(failed_indices) > 5:
                failed_list += f" (+{len(failed_indices)-5} more)"
            
            QMessageBox.warning(self, "Download Complete", 
                f"Downloaded {success_count}/{total} videos.\n\n"
                f"Failed videos: {failed_list}\n\n"
                f"Check if the URLs are valid and not region-restricted.")
        else:
            self.download_status.setText(f"✅ All {total} videos downloaded successfully!")
            self.download_status.setStyleSheet("padding: 10px; font-size: 14px; color: #00FF00;")
            QMessageBox.information(self, "Success", 
                f"All {total} videos downloaded!\n\nFiles are in 'premiere_videos' folder.")
    
    def open_download_folder(self):
        script_dir = os.path.dirname(os.path.abspath(__file__))
        folder = os.path.join(script_dir, 'premiere_videos')
        if not os.path.exists(folder):
            folder = 'premiere_videos'
        if os.path.exists(folder):
            subprocess.run(['open', folder])
        else:
            subprocess.run(['open', '.'])
    
    def browse_file(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Select XML", "", "XML Files (*.xml)")
        if file_path:
            self.file_selected(file_path)
    
    def file_selected(self, file_path):
        if not os.path.exists(file_path):
            QMessageBox.critical(self, "Error", f"File not found: {file_path}")
            return
        
        try:
            if os.path.basename(file_path) != 'timeline.xml':
                shutil.copy(file_path, 'timeline.xml')
            self.process_status.setText(f"✅ Selected: {os.path.basename(file_path)}")
            self.process_status.setStyleSheet("padding: 10px; font-size: 14px; color: #00FF00;")
            self.process_btn.setEnabled(True)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to copy file: {e}")
    
    def start_processing(self):
        if not os.path.exists('timeline.xml'):
            QMessageBox.warning(self, "No File", "Please select timeline.xml first!")
            return
        
        self.process_btn.setEnabled(False)
        self.process_progress.setVisible(True)
        self.process_progress.setValue(0)
        self.open_output_btn.setVisible(False)
        
        self.process_thread = ProcessThread('timeline.xml')
        self.process_thread.progress.connect(self.update_process_progress)
        self.process_thread.finished.connect(self.process_finished)
        self.process_thread.start()
    
    def update_process_progress(self, message, percent):
        self.process_status.setText(message)
        self.process_progress.setValue(percent)
    
    def process_finished(self, success, message):
        self.process_btn.setEnabled(True)
        self.process_progress.setVisible(False)
        
        if success:
            self.process_status.setText("✅ PROCESSING COMPLETE!")
            self.process_status.setStyleSheet("padding: 10px; font-size: 14px; color: #00FF00;")
            self.open_output_btn.setVisible(True)
            QMessageBox.information(self, "Success", message)
        else:
            self.process_status.setText("❌ PROCESSING FAILED")
            self.process_status.setStyleSheet("padding: 10px; font-size: 14px; color: #FF4444;")
            QMessageBox.critical(self, "Error", message)
    
    def open_output_folder(self):
        subprocess.run(['open', os.getcwd()])
    
    def apply_styles(self):
        self.setStyleSheet("""
            QMainWindow, QWidget {
                background-color: #000;
                color: #FFFF00;
            }
            QTabWidget::pane {
                border: 2px solid #FFFF00;
                border-radius: 8px;
                background: #000;
            }
            QTabBar::tab {
                background: #1a1a1a;
                color: #FFFF00;
                padding: 12px 25px;
                margin-right: 2px;
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
                font-weight: bold;
            }
            QTabBar::tab:selected {
                background: #000;
                border: 2px solid #FFFF00;
                border-bottom: none;
            }
            QPushButton {
                background: #FFFF00;
                color: #000;
                border: 2px solid #FFFF00;
                padding: 15px 30px;
                border-radius: 8px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: #000;
                color: #FFFF00;
            }
            QPushButton:disabled {
                background: #333;
                color: #666;
                border-color: #333;
            }
            QTextEdit {
                border: 2px solid #FFFF00;
                border-radius: 8px;
                padding: 10px;
                background: #0a0a0a;
                color: #FFFF00;
                font-family: monospace;
            }
            QProgressBar {
                border: 2px solid #FFFF00;
                border-radius: 8px;
                text-align: center;
                height: 30px;
                background: #0a0a0a;
                color: #000;
                font-weight: bold;
            }
            QProgressBar::chunk {
                background: #FFFF00;
                border-radius: 6px;
            }
            QLabel {
                color: #FFFF00;
            }
            QScrollArea {
                background: #0a0a0a;
            }
        """)


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Creators! Video Automation v2")
    
    # Check for yt-dlp
    try:
        subprocess.run(['yt-dlp', '--version'], capture_output=True, check=True)
    except:
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Critical)
        msg.setWindowTitle("Missing yt-dlp")
        msg.setText("yt-dlp is required but not installed.\n\nInstall it with:\nbrew install yt-dlp")
        msg.exec_()
        return
    
    window = VideoAutomationApp()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
